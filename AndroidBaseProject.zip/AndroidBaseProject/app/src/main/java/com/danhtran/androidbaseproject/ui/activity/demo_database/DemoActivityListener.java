package com.danhtran.androidbaseproject.ui.activity.demo_database;

/**
 * Created by danhtran on 2/25/2018.
 */

public interface DemoActivityListener {
}
